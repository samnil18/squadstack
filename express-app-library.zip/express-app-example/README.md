# Express App Example

This gives a basic idea of the dev and build tools and scripts I use for my
medium sized node apps. For small apps, I'd probably follow the same tooling
setup, but I'd put everything in a single file.

Learn more from my post about this here:
[**How I structure Express apps**](https://kentcdodds.com/blog/how-i-structure-express-apps)

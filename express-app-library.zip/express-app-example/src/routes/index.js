import express from 'express'
import {getLibRoutes} from './lib'

function getRoutes() {
  const router = express.Router()
  router.use('/lib', getLibRoutes())
  return router
}

export {getRoutes}

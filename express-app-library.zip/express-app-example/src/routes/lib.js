import express from 'express';
const lib = require('pipedrive');

function getLibRoutes() {
  const router = express.Router()
  router.get('/search', getPersonByNameOrID)
  router.post('/createWebHookUrl', createWebHookForPersonAddAndUpdate)
  return router
}

lib.Configuration.apiToken = 'IZ8eVLSrEQpHLgmUhrHq3n3t3XQZFNIC'

export const getPersonByNameOrID = async (req, res) => {
	const { id, name } = req.query
	const query = {}
	if (id) {
		query.userId = [id]
	}
	if (name) {
		query.firstChar = name
	}

	if (!id || !name) {
		return res.status(404).send({
			data: 'bad input'
		})
	}

	lib.PersonsController.getAllPersons(input, function(error, response, context) {
		if (error) {
			return res.send(500).send('server error')
		}

		return res.status(200).send(response)
	});
}

export const createWebHookForPersonAddAndUpdate = async (req, res) => {
	const { url } = req.body

	const input = {
		subscriptionUrl: url,
		eventAction: ['added', 'updated'],
		eventObject: 'person',
	}

	
	lib.WebhooksController.createANewWebhook(input, function(error, response, context) {
		if (error) {
			return res.send(500).send('server error')
		}

		return res.status(200).send(response)
	})
}


export {getLibRoutes}